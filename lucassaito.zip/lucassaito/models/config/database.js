module.exports = {
    
    dialect: 'postgres',
    host: 'localhost',
    username: 'usuario',
    password: 'senha',
    database: 'api-node',
    define: {
        timestamps: true,
        undescored: true
}
}