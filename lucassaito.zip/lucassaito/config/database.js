module.exports = {
    dialect: 'postgres',
    host: 'localhost',
    username: 'lucas',
    password: '123',
    database: 'api-node',
    define: {
        timestamps: true,
        underscored: true
    }
}